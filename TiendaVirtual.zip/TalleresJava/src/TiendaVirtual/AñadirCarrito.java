package TiendaVirtual;

public class AñadirCarrito extends Catalogo {
	
	private int i = 0;
	private String[] carrito = new String[10];

	public void añaCarrito(String opcarrito) {
		
		if (opcarrito == "añadir") {
			
			carrito[i] = "";
			
		}
		
	}
}
