package TiendaVirtual;

public class Catalogo {

	private String[] productos = {"Guantes de calavera", "Pijama de Hello Kitty", "Pantalon de cuadros", "Aretes de fresa", "Collar de flor"};
	private int precio1 = 15000;
	private int precio2 = 45000;
	private int precio3 = 28000;
	private int precio4 = 7500;
	private int precio5 = 12400;
	
	public void encabezado() {
		System.out.println("|| Catalogo ||");
		System.out.println ("|| Carrito(0) ||");
	}

	public void infoProductos(int opcion) {

		for(int i = 0; i < productos.length; i++) {
			
			System.out.println(productos[i]);
			System.out.println("");
		}
	}
			
		public void infoProducto(int opcion) {
				
				
			switch (opcion) {
				
			case 0:
					
				break;
					
			case 1:
					
				System.out.println("°°" + productos[0] + "°°");
				System.out.println("");
				System.out.println(precio1);
				System.out.println("Añadir al carrito(añadir)");
				
				break;
				
			case 2:
				
				System.out.println("°°" + productos[1] + "°°");
				System.out.println("");
				System.out.println(precio2);
				System.out.println("Añadir al carrito(añadir)");
				
				break;

			case 3:
				
				System.out.println("°°" + productos[2] + "°°");
				System.out.println("");
				System.out.println(precio3);
				System.out.println("Añadir al carrito(añadir)");
				
				break;

			case 4:
				
				System.out.println("°°" + productos[3] + "°°");
				System.out.println("");
				System.out.println(precio4);
				System.out.println("Añadir al carrito(añadir)");
				
				break;

			case 5:
				
				System.out.println("°°" + productos[4] + "°°");
				System.out.println("");
				System.out.println(precio5);
				System.out.println("Añadir al carrito(añadir)");
				
				break;

					
				
				}
		}
	

}
	
	
			
			
		
	
	

