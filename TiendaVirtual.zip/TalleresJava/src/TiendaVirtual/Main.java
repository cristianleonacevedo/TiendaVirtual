package TiendaVirtual;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {		// TODO Auto-generated method stub

		Scanner scann = new Scanner(System.in);
		
		Catalogo catalogo = new Catalogo();
		
		catalogo.encabezado();
		int opcion = scann.nextInt();
		catalogo.infoProducto(opcion);
		
		scann.close();
	}

}
